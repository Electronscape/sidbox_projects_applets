/*
 * api_music.h
 *
 *  Created on: 25 Jun 2025
 *      Author: electronscape
 */

#ifndef OS_APPAPI_API_MUSIC_H_
#define OS_APPAPI_API_MUSIC_H_


// MUSIC TYPES - SIDBOX API SPECIFICS
// used in LoadAndplay  initplayer
#define	AUDIO_MODE_NULL			0x00	// stops the audio altogether
#define	AUDIO_MODE_WAV			0x02	// basic wave player ;)
#define	AUDIO_MODE_SID			0x03	// this is our signature function for the SIDBOX
#define	AUDIO_MODE_STP2			0x04	// Maddi's function win! PLEASE... work!
#define	AUDIO_MODE_MOD			0x05	// the protracker mod play
#define	AUDIO_MODE_YM			0x06	// the Atari ST YM playback
#define	AUDIO_MODE_S3M			0x07	// S3M Play back
#define	AUDIO_MODE_AY			0x08	// Spectrum AY Track
#define	AUDIO_MODE_POKEY		0x09	// Pokey audio systems
#define	AUDIO_MODE_TFMX			0x0B	// TFMX Play back
#define	AUDIO_MODE_MED			0x12	// Amiga OctaMED MDD0/1


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ########################################################################################################### //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
struct __attribute__((aligned(4))) music_api { //########################### MUSIC PLAYER API ###################
	void (*UpdatePlayer)	(void);				// run the player (music routines time keeping)
	void (*LoadAndplay)		(char* filename, uint8_t player, uint8_t param1);
	void (*musiccom)		(uint32_t commandbits);	// will figure something out for this

	// initplayer(musictype, param1);						// ensure music is loaded in memory address starting 0xD0000000
	int (*initplayer)		(uint8_t musictype, uint8_t param1);	// use if music is loaded in memory (param 1 if your tune has sub tunes)
};


#endif /* OS_APPAPI_API_MUSIC_H_ */
