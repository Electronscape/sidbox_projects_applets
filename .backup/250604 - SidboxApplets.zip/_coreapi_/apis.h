#include <stdint.h>


#ifndef SIDBOX_OS_API_H_
#define SIDBOX_OS_API_H_

#define FILESYSAPI

/* These types MUST be 16-bit or 32-bit */
typedef int				INT;
typedef unsigned int	UINT;

/* This type MUST be 8-bit */
typedef unsigned char	BYTE;

/* These types MUST be 16-bit */
typedef short			SHORT;
typedef unsigned short	WORD;
typedef unsigned short	WCHAR;

/* These types MUST be 32-bit */
typedef long			LONG;
typedef unsigned long	DWORD;

/* This type MUST be 64-bit (Remove this for ANSI C (C89) compatibility) */
typedef unsigned long long QWORD;
typedef DWORD FSIZE_t;
typedef char TCHAR;

#define MAX_DEPTH 256

extern long _Randseed;

// Align to 4 byte memory location
#define ALIGN4(x) (((x) + 3) & ~3)

// SIDBOX EXTERNAL RAM STARTS AT 0xD0000000
#define RAMLOCATION		0xD0000000
// Exported applet entry point function (must match ENTRY in ld script)
extern _largest_modfile;


// ## MEMORY ALIGNMENT FOR DMA AND PERFORMANCE ##
// These alignment attributes help ensure that memory structures are placed at
// boundaries compatible with DMA hardware and faster memory access.
// Use them for large graphics buffers, tightly timed variables, and
// anywhere unaligned memory access may cause issues or slowdowns.
#define MEMALIGN4    __attribute__((aligned(4)))    // Align to 4-byte boundary (basic word alignment)
#define MEMALIGN8    __attribute__((aligned(8)))    // Align to 8-byte boundary (often used for 64-bit types)
#define MEMALIGN16   __attribute__((aligned(16)))   // Align to 16-byte boundary (good for SIMD and cache lines)
#define MEMALIGN32   __attribute__((aligned(32)))   // Align to 32-byte boundary (ideal for DMA transfers and large buffers)


// STM32H743 REGISTER ADDRESSES 
#define SCB_CCR              (*(volatile uint32_t *)0xE000ED14)
#define SCB_CCR_DIV_0_TRP    (1 << 4)
#define DIVZEROON			SCB_CCR |=  SCB_CCR_DIV_0_TRP;
#define DIVZEROOFF			SCB_CCR &= ~SCB_CCR_DIV_0_TRP;

// DEFAULT BUFFER LOCATION IN RAM
// NOTE: If you change the buffers, make sure aligned ! use __attribute__((aligned(32)))
#define RAM_LCD_DISPLAYBUFFER1	(RAMLOCATION | 0x6B2000)	// DEFAULT RECOMMENDED DISPLAY BUFFERS
#define RAM_LCD_DISPLAYBUFFER2	(RAMLOCATION | 0x6D9000)	// DEFAULT RECOMMENDED DISPLAY BUFFERS


// HARDWARE BUTTONS
#define BTN_NULL	0x00
#define BTN_FIRE 	0x01
#define BTN_FIRE2 	0x02
#define BTN_UP 		0x04
#define BTN_DOWN 	0x08
#define BTN_LEFT 	0x10
#define BTN_RIGHT 	0x20




/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// #################### API INTERFACE HEADER ################################################################# //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// ### GLOBAL DEFS
#define API_MAX_FILES_FSFIL		4
#define MAX_AUDIO_CHANNELS		8


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//##[ API INCLUDES ]#############################################################################################
//																												#
#include "api_gfx.h"			//																				#
#include "api_math.h"			//																				#
#include "api_sys.h"			//																				#
#include "api_filesys.h"		//																				#
#include "api_su.h"				//																				#
#include "api_music.h"			//																				#
#include "api_sound.h"			//																				#
//																												#
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//##[ API INTERFACE ROOT ]#######################################################################################
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
__attribute__((aligned(4)))
typedef struct {

	// Operating system Controls
	struct superuser_api 	su;			// super user access
	struct sys_api			sys;		// system access
	struct fs_api			filesys;	// file system access

	// Integer Mathing!
	struct maths_api		math;		// mathmatic preloaded routines

	// SIDBOX Intended operations
	struct gfx_api 			gfx;		// graphics api
	struct music_api 		music;		// music access
	struct sound_api 		snd;		// channels and audio settings control bits

}  SidboxAPI;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// #################### END API INTERFACE #################################################################### //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef __INTELLISENSE__
/// VSCode IntelliSense helper: allow member suggestions on SBAPI->
static volatile SidboxAPI* SBAPI = (volatile SidboxAPI*)0x2001F000;
#define API SBAPI
#else
#define SBAPI ((volatile SidboxAPI *)0x2001F000)
#define API SBAPI
#endif




/////////////////// HELPERS THOUGH BADLY NAMED, SORRY ///////////////////////////////////////////////////////////
// KERNAL API
#define dbug(...)				SBAPI->sys.printf(__VA_ARGS__)	// (const char *fmt, ...)
#define delayMilliSecond		SBAPI->sys.delayMs		// (unsigned short milli);

// GRAPHICS HARDWARE API

// GRAPHICS ROUTINES API
#define APIGFXRectF     		SBAPI->gfx.rectf		// (int16_t x, int16_t y, int16_t w, int16_t h);
#define APIGFXRect     			SBAPI->gfx.rect			// (int16_t x, int16_t y, int16_t w, int16_t h);

// GRAPHICS MEMORIES
#define APIGFXFGBuffer			(*(SBAPI->gfx.ActiveBuffer))	// *uint8_t	// show buffer
#define APIGFXDGBuffer			(*(SBAPI->gfx.DrawBuffer))	// uint8_t	// draw buffer
#define APIGFXBKBuffer			(*(SBAPI->gfx.BackBuffer))	// uint8_t	// back layer buffer

#define APIGFXFGColour			(*(SBAPI->gfx.forecolour))	// uint8_t	// forecolor
#define APIGFXBGColour			(*(SBAPI->gfx.backcolour))	// uint8_t	// backcolor for mainly textblock colour

#define APIGFXDrawTextFGF		SBAPI->gfx.drawtextf	// DrawText FAST ForeGround
#define APIHWButtons			SBAPI->sys.hwbuttons

#define APIMusicCMD				SBAPI->music.musiccom		// (uint32_t commandbits); 0x00000000 just stops music play back

#define api_getmousex			(*(SBAPI->sys.mouseposx))	// mouse coords x-axis
#define api_getmousey			(*(SBAPI->sys.mouseposy))	// mouse coords y-axit

#define api_getmousexd			(*(SBAPI->sys.mouseposxd))	// mouse coords x-axis
#define api_getmouseyd			(*(SBAPI->sys.mouseposyd))	// mouse coords y-axit


#define fsload					SBAPI->filesys.loadfile		// opens, loads and closes
#define APULCDUpdatePallete		SBAPI->gfx.clut		// (*clut, layer) change colours 32bit colours 0x00RRGGBB

#define	APIDrawLineMode			(*(SBAPI->gfx.Drawmode))	// *uint8_t
#define APIDrawline				SBAPI->gfx.drawline		//(short x0, short y0, short x1, short y1);
#define	APIDrawPoint			SBAPI->gfx.setpixel		//(short x0, short y0)

// MATHMATICS ROUTINES
#define	APIsinff				SBAPI->math.sinff
#define	APIcosff				SBAPI->math.cosff
#define	APIsinfi				SBAPI->math.sinfi
#define	APIcosfi				SBAPI->math.cosfi

// GRAPHICS ROUTINES
#define api_blitSolid			SBAPI->gfx.blitsolid
#define api_blitSolidt			SBAPI->gfx.blitsolidT
//#define APIAudio

#define fast_cos 				APIcosff
#define fast_sin 				APIsinff


// --------- ADD THIS IF YOU WANT IT ------------------
#define EXITME	\
	uint8_t exiter = ExitCode();\
	if(exiter) return(exiter);

#endif

