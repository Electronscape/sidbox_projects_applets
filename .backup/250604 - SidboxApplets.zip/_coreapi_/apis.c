#include <stdarg.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "apis.h"


// Random Generator (crude but works)
long _Randseed = 402;
signed short randomx(unsigned short range){
    _Randseed = _Randseed * 11 + 125;
    return ((signed short)(_Randseed >> 16) % range);
}



void ChannelAssign(uint8_t chan, uint8_t *addr, uint32_t freq, int vol, uint32_t len, uint8_t loop){
	if (!SBAPI->snd.channel[chan]) {
		SBAPI->sys.printf("AssignSound: api_aud[%u] is NULL!\r\n", chan);
		return;
	}
	//struct sample_banger channel;
	//channel.lSampPtr = addr;
	//channel.volume	 = vol;
	//channel.lFreq	 = freq;
	//channel.lSampleLen = len;
	//memcpy(SBAPI->api_aud[chan], &channel, sizeof(channel));

	SBAPI->snd.channel[chan]->lSampPtr = addr;
	SBAPI->snd.channel[chan]->volume = vol * 2;
	SBAPI->snd.channel[chan]->lFreq = freq;
	SBAPI->snd.channel[chan]->lSampleLen = len;
	SBAPI->snd.channel[chan]->bLooping = loop;

	//default loop
	SBAPI->snd.channel[chan]->lLoopStart = 0;
	SBAPI->snd.channel[chan]->lLoopEnd = len;

}

void PlayChannel(uint8_t chan){
	SBAPI->snd.channel[chan]->bPlaying = 1;
}

void StopChannel(uint8_t chan){
	SBAPI->snd.channel[chan]->bPlaying = 0;
}

void SetChannelFrequency(uint8_t chan, int freq){
	SBAPI->snd.channel[chan]->lFreq = freq;
}

void SetChannelVolume(uint8_t chan, int vol){
	SBAPI->snd.channel[chan]->volume = vol;
}

int GetChannelVolume(uint8_t chan){
	return SBAPI->snd.channel[chan]->volume;
}


/// TIMERS ISR INTERUPTS
/*
_weak void ISRT1A(){
	// this is the Timer A - 
}
*/

