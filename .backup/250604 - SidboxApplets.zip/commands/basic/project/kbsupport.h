#ifndef KBSUPPORT_H
#define KBSUPPORT_H

#define TEXTBUFFER_SIZE 64
#define KEY_BACKSPACE 0x08


#endif