#!/bin/bash
echo "BEGIN COMPILING APPLET FOR SIDBOX!! (YEY!!)"

set -e  # exit on error

# Change to argument directory if given, else current
if [ -n "$1" ]; then
  cd "$1"
fi

# Clear and recreate compiled directory
rm -rf compiled
mkdir -p compiled

# Options
optimise_core="-Ofast"
optimise_app="-Ofast"

FieldOptions='-mcpu=cortex-m7 -mthumb -mfpu=fpv5-d16 -std=gnu99 -c -ffunction-sections -fdata-sections -Wall -fstack-usage --specs=nano.specs -mfloat-abi=hard'
FieldLinker='-mcpu=cortex-m7 --specs=nosys.specs -Wl,--gc-sections -static --specs=nano.specs -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -Wl,--start-group -lc -lm -Wl,--end-group'

# Compile core files in background
for f in ../_coreapi_/*.c; do
  echo "Compiling $f"
  arm-none-eabi-gcc -w $FieldOptions $optimise_core -c "$f" -o "compiled/$(basename "${f%.c}").o" &
done
wait

# Compile project files recursively in background
while IFS= read -r -d '' f; do
  echo "Compiling $f"
  arm-none-eabi-gcc -w $FieldOptions $optimise_app -c "$f" -o "compiled/$(basename "${f%.c}").o" &
done < <(find project -type f -name '*.c' -print0)
wait

if [ ! -f compiled/main.o ]; then
  echo
  echo
  echo "NO MAIN.O"
  echo "********** Compile ABORTED! **********"
  exit 1
fi

arm-none-eabi-gcc $FieldLinker -T applet.ld -Wl,-Map=compiled/output.map compiled/*.o -o compiled/applet.elf

if [ ! -f compiled/applet.elf ]; then
  echo
  echo
  echo "NO applet.elf"
  echo "********** Compile ABORTED! **********"
  exit 1
fi

arm-none-eabi-objcopy -O binary compiled/applet.elf applet.app
arm-none-eabi-objdump -d compiled/applet.elf > applet.asm
echo
echo

arm-none-eabi-size compiled/applet.elf
echo
echo

arm-none-eabi-nm -n compiled/applet.elf | grep applet_entry || true
arm-none-eabi-nm -n compiled/applet.elf | grep main || true
echo
echo
echo "---- COMPILE COMPLETED ----"
echo

# File size formatting with commas
FILE="applet.app"

if [ ! -f "$FILE" ]; then
  echo "File not found: $FILE"
  exit 1
fi

SIZE=$(stat -c%s "$FILE")

# Function to add commas to file size
add_commas() {
  # Bash version of comma formatting
  echo "$1" | rev | sed -E 's/([0-9]{3})/\1,/g' | rev | sed 's/^,//'
}

formatted_size=$(add_commas $SIZE)
echo "Size of $FILE is $formatted_size bytes"

exit 0
