#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
#include <string.h>
#include <math.h>
#include <stdarg.h>
#include <stdlib.h>

#include "../../_coreapi_/apis.h"

static uint8_t hwbutts;		// buffer for hardware button presses
volatile uint8_t *fgmem;	// painter to the forground draw buffer
volatile uint8_t *bgmem;	// pointer to backbuffer memory

uint32_t OCSBackBuffer;			// store original backlayer buffer pointer

__attribute__((aligned(4))) 
volatile uint8_t fieldb[960 * 640]; // big ass back image
volatile uint8_t fielda1[960 * 640]; // big ass back image
volatile uint8_t fielda2[960 * 640]; // big ass back image

static void initDisplayBuffers(){
	*SBAPI->gfx.ActiveBuffer = fielda1;	// base address
	*SBAPI->gfx.DrawBuffer 	= fielda1;	// base address

	fgmem = *SBAPI->gfx.DrawBuffer;	// DrawGround access	// going to only draw at the active buffer CRAP no double buffering
	bgmem = SBAPI->gfx.ActiveBackLayerBuffer;	// background access
	OCSBackBuffer = *SBAPI->gfx.ActiveBackLayerBuffer;	// backup the original address, we might redirect the backbuffer to another location
}



void ShowBuffer(int db){
	if(db){
		*SBAPI->gfx.ActiveBuffer = fielda1;	// Default locations - used in the OS, but safe to use
		*SBAPI->gfx.DrawBuffer 	= fielda2;
	} else {
		*SBAPI->gfx.ActiveBuffer = fielda2;	// Default locations - used in the OS, but safe to use
		*SBAPI->gfx.DrawBuffer 	= fielda1;
	}
}

// Align to 4 byte memory location
#define ALIGN4(x) (((x) + 3) & ~3)



// MAIN PROGRAM :)
int main(int arg, char *argv[]){
    uint8_t txt[128];
    uint8_t idb;
	DIVZEROOFF;			// turn off DIV BY ZERO error - sometimes the CPU just farts at random with this on
	SBAPI->sys.delayMs(100);
	SBAPI->gfx.setBacklightBrightness(255);	// turn off backlight	// so we hide all the messy graphics initialisation startup

	_Randseed=0;	// reset random seed to zero (boring, i know)
	dbug("Dual Play\r\n\r\n"); // send message to UART 
	SBAPI->sys.delayMs(10);	// wait for a moment

	initDisplayBuffers();	// setup graphics buffer pointers

	// Stop all active channels playing
	StopChannel(0);
	StopChannel(1);
	StopChannel(2);
	StopChannel(3);
	StopChannel(4);
	StopChannel(5);
	StopChannel(6);
	StopChannel(7);
	
	SBAPI->gfx.displaymode(960, 640, 960, 640, DISPFLAG_DUALLAYER );	// the big bitmap is double the height -- essential startup 
	*SBAPI->gfx.DrawBuffer 	= fielda1;	// set lcd_drawbuffer for the api_graphics routines to work
	SBAPI->gfx.setBitmapDimentions(960, 640);	// set the current bitmap draw dimentions, without it, your draw,pixels,cirlces will look wrong
	static int colorindex=0;
	for(int i=640; i>0; i-=16){
		colorindex = 1 - colorindex;
		*SBAPI->gfx.forecolour = colorindex * 79;
		SBAPI->gfx.drawcircle(480,320, i,1);
	}

	// copy the two buffers, (Active and Draw buffer : Used for the main play field)
	memcpy(fielda2, fielda1, 960 * 640);	// copy the buffer to one we just drawn two
	memset((uint8_t *)fieldb, 0x00, (960 * 640));
	SBAPI->gfx.setBitmapDimentions(960, 640);

	*SBAPI->gfx.DrawBuffer 	= (uint8_t *)fieldb;	// set lcd_drawbuffer for the api_graphics routines to work
	colorindex=1;
	for(int i=640; i>0; i-=16){
		colorindex = 1 - colorindex;
		*SBAPI->gfx.forecolour = colorindex * 31;
		SBAPI->gfx.drawcircle(480,320, i, 1);
	}
	
	//SBAPI->api_setBitmapDimentions(SF_SCREENWIDTH, SF_SCREENHEIGHT);
	dbug("Drawn BigBack Cirlces\r\n");


	*SBAPI->gfx.ActiveBackLayerBuffer  = (uint8_t*)fieldb;					// change the backlayer to our bigbackground (image rotated 90 from source work)
	//SBAPI->api_displaymode(480, 320, 960, 640, DISPFLAG_DUALLAYER);	// the big bitmap is double the height
	SBAPI->gfx.setFGViewport(0,0);
	SBAPI->gfx.setBGViewport(0,0);
	ShowBuffer(0);
	
	int exitCnt = 0;

	int bitmap1x, bitmap1y, bitmap2x, bitmap2y;
	int rotation1 = 0;
	int rotation2 = 0;
	int rotation3 = 0;
	int rotation4 = 0;

	// our main loop
	while(1){
		hwbutts = APIHWButtons();	// get button presses
       	if(hwbutts & BTN_FIRE2) {	// pressed, exit back out to the OS
			exitCnt++;
			if(exitCnt>50){	// hold for 1 second (50fps)
				return(0x7);
			}
			
       	} else exitCnt=0;

		rotation1 ++ ;  if(rotation1> 359)rotation1=0;
		rotation2 += 2 ;  if(rotation2> 359)rotation2=0;

		rotation3 += 3; if(rotation3> 359)rotation3=0;
		rotation4 += 4; if(rotation4> 359)rotation4=0;


		bitmap1x = 240 + APIcosff(rotation1) * (240);
		bitmap1y = 160 + APIsinff(rotation3) * (160);	// since -320 to +320 in a full sinff :)

		bitmap2x = 240 + APIcosff(rotation2) * (240);
		bitmap2y = 160 + APIsinff(rotation4) * (160);	// since -320 to +320 in a full sinff :)
		
		SBAPI->gfx.setFGViewport(bitmap1x, bitmap1y);
		SBAPI->gfx.setBGViewport(bitmap2x, bitmap2y);
		

		// do the display bits after --------------
		ShowBuffer(idb);	// swap the active and drawbuffer around
		idb = 1 - idb;		// toggle buffer id
		// time to display it!
		SBAPI->gfx.waitvsync();
		SBAPI->gfx.render(1);		// 1 = dual layer render, vwait already done :)
		SBAPI->music.UpdatePlayer();			// need this to enable to the sound
	}
	return 0;	// exited with success
}






