#include <stdbool.h>
#include <stdint.h>


#ifndef PATTERNBANKS_H
#define PATTERNBANKS_H










#endif