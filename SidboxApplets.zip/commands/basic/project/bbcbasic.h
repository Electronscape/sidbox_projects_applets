#ifndef BBC_VM_H
#define BBC_VM_H

void interpret_line(const char *line);

#endif