#include <stdint.h>
#include <stdbool.h>
#include "apis.h"


#ifndef API_KBSUPPORT_H
#define API_KBSUPPORT_H







#define TEXTBUFFER_SIZE 64
#define KEY_BACKSPACE   0x08

#define HID_BACKSPACE   0x2A
#define HID_RETURN      0x28

extern uint8_t textbuffer_index;
extern char textbuffer[TEXTBUFFER_SIZE];
extern uint8_t last_keyReport[];


// our interrupt prototype function
// eg. SBAPI->sys.interruptVector->keyboard_isr = &KB_ISR;
__weak void KB_ISR(uint8_t *packet);



#endif